<?php
	$name = $_POST['name'];
	$visitor_email = $_POST['email'];
	$message = $_POST['message'];

	$emaill_form = 'polytechnicacademy.in@gmail.com';
	$email_subject = "Contact Us | Polytechnic Academy";
	$email_body = "Sender Name: $name \n"."Sender Email: $visitor_email \n"."Sender Message: $message \n";

	$to = "polytechnicacademy.in@gmail.com";

	$headers = "Form: $email_form \r\n";

	$headers = "Reply-To: $visitor_email \r\n";

	mail($to, $email_subject, $email_body, $headers);
	header("Location: index.html");
?>