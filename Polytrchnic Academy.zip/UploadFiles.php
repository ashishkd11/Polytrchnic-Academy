<?php
	$name = $_POST['name'];
	$visitor_email = $_POST['email'];
	$semester = $_POST['semester'];
	$branch = $_POST['branch'];
	$item = $_POST['item'];
	$url = $_POST['url'];
	$display = $_POST['display'];
	$message = $_POST['message'];

	$emaill_form = 'polytechnicacademy.in@gmail.com';
	$email_subject = "Upload PDF's Links| Polytechnic Academy";
	$email_body = "Sender Name: $name \n"."Sender Email: $visitor_email \n"."Semester: $semester \n"."Branch: $branch \n"."Item: $item \n"."Url: $url \n"."Can we display?: $display \n"."Sender Message: $message \n";

	$to = "polytechnicacademy.in@gmail.com";

	$headers = "Form: $email_form \r\n";

	$headers = "Reply-To: $visitor_email \r\n";

	mail($to, $email_subject, $email_body, $headers);
	header("Location: index.html");
?>