<?php
//index.php

?>
<!DOCTYPE html>
<html>
 <head>
  <title> Ask your Questions to Polytechnic Academy</title>
  <meta name="description" content=" Polytechnic Academy is a Free website where you will get Polytechnic Books, Polytechnic Solutions, Polytechnic Notes, Polytechnic Important Questions, Polytechnic Syllabuses, & Many more thing in PDF form. ">
  <meta name="keyword" content=" Polytechnic, Diploma in Engineering, Polytechnic Academy, Polytechnic Book, Polytechnic Solutions, Polytechnic Notes, polytechnic Syllabuses, Jharakhand Polytechnic, Bihar Polytechnic, Government Polytechnic, Polytechnic all semesters Solutions, ">
  <meta name="author" content=" Ashish Kumar | Polytechnic Academy ">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link rel="icon" href="https://www.polytechnicacademy.in/Images/favicon.png">
  
  <style type="text/css">
    @import url('https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700&display=swap');
    *{
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Montserrat',sans-serif;
      }
    h2{
      color: #000;
      text-align: center;
    }
    .container{
      box-sizing: border-box;
      text-align: center;
    }
    form{
      box-sizing: border-box;
      border: 25px solid #E0F7FA;
      border-radius: 10px;
      background-color: #E0F7FA;
      margin: 0px 30px;
    }
    .form-control{
      box-sizing: border-box;
      border: 2px solid #000;
      border-radius: 10px;
      margin: 15px 20px;
      height: 50px;
      width: 90%;
    }
    nav{
    background: #3452BA;
    padding: 5px 40px;
    }
    nav ul{
    list-style: none;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: center;
    }
    nav ul li{
    padding: 15px 0;
    cursor: pointer;
    }
    nav ul li.items{
    position: relative;
    width: auto;
    margin: 0 16px;
    text-align: center;
    order: 3;
    }
    nav ul li.items:after{
    position: absolute;
    content: '';
    left: 0;
    bottom: 5px;
    height: 2px;
    width: 100%;
    background: #33ffff;
    opacity: 0;
    transition: all 0.2s linear;
    }
    nav ul li.items:hover:after{
    opacity: 1;
    bottom: 8px;
    }
    nav ul li.logo{
    flex: 1;
    color: white;
    font-size: 23px;
    font-weight: 600;
    cursor: default;
    user-select: none;
    }
    nav ul li a{
    color: white;
    font-size: 18px;
    text-decoration: none;
    transition: .4s;
    }
    nav ul li:hover a{
    color: cyan;
    }
    nav ul li i{
    font-size: 23px;
    }
    nav ul li.btn{
    display: none;
    }
    nav ul li.btn.hide i:before{
    content: '\f00d';
    }

    .App{
  text-align: center;
}

.App img{
  margin: 10px;
  width: 320px;
  height: 100px;
}

.Dis{
  text-align: center;
  margin: 0 29%;
}

.Dis p{
  text-align: center;
  color: #fff;
  margin: 10px 0;
  font-size: 15px;
}

.Menu {
  text-align: center;
  width: 100%;
  margin: 10px 0;
}

.Menu ul{
  list-style-position: inside;
}

.Menu ul p{
  font-size: 18px;
  display: inline;
  margin: 10px 10px;
  border: 1px solid lightgrey;
  border-radius: 3px;
  background: #fff;
  padding: 2px 4px;
}

.Menu ul p a{
  color: #407dd3;
  text-decoration-line: none;
}


.f-info {
  text-align: center;
  border-top: 0.5px solid lightgrey;
  padding: 10px;
}










@media screen and (max-width:1067px){
.Dis{
  text-align: center;
  margin: 0 30px;
  }

  .Menu ul p{
    font-size: 15px;
  display: inline-block;
  margin: 5px 10px;
}
}
    

  </style>
</head>
<body>
  <nav>
    <!--Menu Bar-->
    <ul>
    <li class="logo"> <a href="https://www.polytechnicacademy.in/"> Polytechnic Academy </a></li>
    <li class="items"><a href="https://www.polytechnicacademy.in/">Home</a></li>
    </ul>
    </nav>
    
<div class="separator" style="clear: both; background: linear-gradient( rgb(83, 59, 207), rgb(40, 206, 217)); text-align: center;">
  <img border="0" data-original-height="500" data-original-width="300" height="300" src="https://www.polytechnicacademy.in/Images/Logo1.png" width="300" /></div>
<br>

<br>
  <h2>Ask your Questions to Polytechnic Academy</h2>
<br>
<hr style="color: black; margin: 20px 20px;">
  <div class="container">
    <form method="POST" id="comment_form">
      <div class="form-group">
        <h4 style="text-align: left; margin-left: 20px;">Enter Name</h4>
        <input type="text" name="comment_name" id="comment_name" class="form-control" placeholder="Enter Name" autocomplete="off" />
      </div>
      <div class="form-group">
        <h4 style="text-align: left; margin-left: 20px;">Ask Your Questions <span style=" font-size: 11px;"> ( </span> <span style=" font-size: 11px; color: red;"> With Email </span><span style=" font-size: 11px;"> ) </span> </h6>
        <textarea name="comment_content" id="comment_content" class="form-control" placeholder="Type Your Question + (Email id)" rows="5"></textarea>
      </div>
      <div class="form-group">
        <input type="hidden" name="comment_id" id="comment_id" value="" />
        <input type="submit" name="submit" id="submit" class="btn btn-info" value="Submit" />
      </div>
    </form>
    <span id="comment_message"></span>
  <br>
    <div id="display_comment"></div>
  </div>

<script>
$(document).ready(function(){
 
 $('#comment_form').on('submit', function(event){
  event.preventDefault();
  var form_data = $(this).serialize();
  $.ajax({
   url:"add_comment.php",
   method:"POST",
   data:form_data,
   dataType:"JSON",
   success:function(data)
   {
    if(data.error != '')
    {
     $('#comment_form')[0].reset();
     $('#comment_message').html(data.error);
     $('#comment_id').val('');
     load_comment();
    }
   }
  })
 });

 load_comment();

 function load_comment()
 {
  $.ajax({
   url:"fetch_comment.php",
   method:"POST",
   success:function(data)
   {
    $('#display_comment').html(data);
   }
  })
 }

 $(document).on('click', '.reply', function(){
  var comment_id = $(this).attr("id");
  $('#comment_id').val(comment_id);
  $('#comment_name').focus();
 });
 
});
</script>


<!--Footer-->
<div style="text-align: center;">
<span style="font-family: &quot;arial&quot; , &quot;helvetica&quot; , sans-serif;"><br /></span></div>
<div style="text-align: left;">
<br>
  <div class="separator" style="clear: both; text-align: center; padding: 8px 0px 8px 0px; background: #E0F7FA; ">
  <h2 style=" box-sizing: border-box; color: #172337; font-family: muliregular; text-align: center; text-transform: capitalize; ">
  Quick Links</h2>
  </div>
  <br>
    <ul class="foot-link" style="box-sizing: border-box; list-style-position: inside; margin-top: 0px; padding-left: 0px; text-align: center;">
        <br>
            <li style="box-sizing: border-box; display: inline-block; padding-left: 10px;"> <a href="https://www.polytechnicacademy.in/Solutions/" style=" text-decoration-line: none;" > <span style="box-sizing: border-box; color: #407dd3; font-size: 20px;" target="top"> Solutions, </span> </a> </li>
            <li style="box-sizing: border-box; display: inline-block; padding-left: 10px;"> <a href="https://www.polytechnicacademy.in/EBooks/" style=" text-decoration-line: none;" > <span style="box-sizing: border-box; color: #407dd3; font-size: 20px;" target="top"> E-Books, </span> </a> </li>
            <li style="box-sizing: border-box; display: inline-block; padding-left: 10px;"> <a href="https://www.polytechnicacademy.in/Notes/" style=" text-decoration-line: none;" > <span style="box-sizing: border-box; color: #407dd3; font-size: 20px;" target="top"> Notes, </span> </a> </li>
            <li style="box-sizing: border-box; display: inline-block; padding-left: 10px;"> <a href="https://www.polytechnicacademy.in/ImportantQuestions/" style=" text-decoration-line: none;" > <span style="box-sizing: border-box; color: #407dd3; font-size: 20px;" target="top"> Important Questions, </span> </a> </li>
            <li style="box-sizing: border-box; display: inline-block; padding-left: 10px;"> <a href="https://www.polytechnicacademy.in/Syllabuses/" style=" text-decoration-line: none;" > <span style="box-sizing: border-box; color: #407dd3; font-size: 20px;" target="top"> Syllabuses, </span> </a> </li>
            <li style="box-sizing: border-box; display: inline-block; padding-left: 10px;"> <a href="https://www.polytechnicacademy.in/Assignments/" style=" text-decoration-line: none;" > <span style="box-sizing: border-box; color: #407dd3; font-size: 20px;" target="top"> Assignments, </span> </a> </li>
        </ul>
  </div>
<br>
<footer>
<div class="footer" >
<div class="footer" style="background-color: white" >
  <br>
<div class="footaddress" style=" box-sizing: border-box; border-bottom: 2px solid rgb(234, 234, 234); border-top: 2px solid rgb(234, 234, 234); box-sizing: border-box; color: #333333; font-family: muliregular; font-size: 13.2px; padding: 15px 0px; text-align: center;">
<br>
<i class="fa fa-pencil-square-o" ></i> <h2 style="Color: Black;"> <u> Follow Me </u> </h2> <br> <br>
<ul class="nav footer-nav">
  <br>
  <li>
  <a href="https://www.facebook.com/Ashishkd11" target="_blank">
  <img src="https://www.polytechnicacademy.in/Images/Facebook Logo.png" style=" width: 50px; height: 50px;">
  </a>
  </li>
  <li>
  <a href="https://www.instagram.com/ashish_kd_11/" target="_blank">
  <img src="https://www.polytechnicacademy.in/Images/Instagram Logo.png" style=" width: 50px; height: 50px;">
  </a>
  </li>
  <li>
  <a href="https://mobile.twitter.com/ashish_kd_11" target="_blank">
  <img src="https://www.polytechnicacademy.in/Images/Twitter Logo.png" style=" width: 50px; height: 50px;">
  </a>
  </li>
  <li>
  <a href="https://www.linkedin.com/in/ashishkd11/" target="_blank">
  <img src="https://www.polytechnicacademy.in/Images/Li.png" style=" width: 50px; height: 50px;">
  </a>
  </li>
</ul>
<br>
</div>
<br>
<footer style="background-color: #172337; font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0; width: 100%; padding: 0px;">
  <div class="App">
    <a href="https://www.polytechnicacademy.in/DownloadApp/PolytechnicAcademy.apk"><img src="https://www.polytechnicacademy.in/Images/appicon.png"></a>
  </div>
  <div class="Dis">
    <p>Polytechnic Academy is a Education sharing website. The main goal of Polytechnic Academy is Every students should be prepared for there examinations.<br> <br> A Step for Digital Education.   
  <br> <br>
    Mail at: <a href="mailto:polytechnicacademy.in@gmail.com" title="send an email to polytechnicacademy.in@gmail.com" style=" Color: red; text-decoration-line: none; ">polytechnicacademy.in@gmail.com</a> </P>
  </div>

  <div class="Menu">
    <ul>
      <p> <a href="https://www.polytechnicacademy.in/sitemap.xml"> Sitemap </a> </p>
      <p> <a href="https://www.polytechnicacademy.in/AboutUs.html"> About Us </a> </p>
      <p> <a href="https://www.polytechnicacademy.in/ContactUs/index.html"> Contact Us </a> </p>
      <p> <a href="https://www.polytechnicacademy.in/Disclaimer.html"> Disclaimer </a> </p>
      <p> <a href="https://www.polytechnicacademy.in/PrivacyPolicy.html"> Privacy Policy </a> </p>
      <p> <a href="https://www.polytechnicacademy.in/T&C.html"> Terms & Conditions </a> </p>
      <p> <a href="https://www.polytechnicacademy.in/AskQuestions/index.php"> Ask your Questions </a> </p>
    </ul>
  </div>
  <div class="f-info">
    <p style="color: white; font-size: 15px;" >&#169; 2020&nbsp;-&nbsp; 2021 &nbsp; <a href="https://www.polytechnicacademy.in/" style="box-sizing: border-box; color: red; margin: 0px; font-size: 15px; padding: 0px; text-decoration-line: none;"> PolytechnicAcademy.in </a><br> 
      <span style="color: white; font-size: 15px;" > Owned by <a href="https://www.polytechnicacademy.in/Ashish/" style="box-sizing: border-box; color: red; margin: 0px; font-size: 15px; padding: 0px; text-decoration-line: none;"> Ashish Kumar </a> </span>
    </p>
  </div>
</footer>
</div>
</div>
</footer>
</body>
</html>